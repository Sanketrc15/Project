package com.cd.dao;

import java.util.ArrayList;
import java.util.HashMap;
import com.cd.model.Mobile;

public class MobileDaoImpl implements IMobileDAO{

	
	
	public void addMobile(Mobile m) {
		
		ArrayList<Mobile> list=new ArrayList<Mobile>();
		
		list.add(m);
		System.out.println(".");System.out.println(".");System.out.println(".");
		System.out.println("The added brand is " +m.getName() +" and it's ID is "+ m.getId());
	}

	public void deleteMobile(int mId) {
		// TODO Auto-generated method stub
		
		
		HashMap<Integer,String> Hmap = new HashMap <Integer, String>();
		
		Hmap.put(88888881,"Nokia");
		Hmap.put(88888882,"Samsung");
		Hmap.put(88888883,"Apple");
		Hmap.put(88888884,"Sony");
		Hmap.put(88888885,"Google");
		Hmap.put(88888886,"Honor");
		Hmap.put(88888887,"MI");
		Hmap.put(88888888,"Blackberry");
		
		System.out.println(Hmap);
		System.out.println(Hmap.remove(mId));
		System.out.println("The mobile having Id " +mId+" and brand " + Hmap.get(mId) +" is removed");
		/*
		 * Set set = Hmap.entrySet(); java.util.Iterator iterator = set.iterator();
		 * while(iterator.hasNext()) { Map.Entry mentry = (Map.Entry)iterator.next();
		 * System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
		 * System.out.println(mentry.getValue()); }
		 */
	}
	
	public void updateMobileDetails(int mId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void searchMobileById(int mId) {
		// TODO Auto-generated method stub
		
		HashMap<Integer,String> Hmap = new HashMap <Integer, String>();
		
		Hmap.put(88888881,"Nokia");
		Hmap.put(88888882,"Samsung");
		Hmap.put(88888883,"Apple");
		Hmap.put(88888884,"Sony");
		Hmap.put(88888885,"Google");
		Hmap.put(88888886,"Honor");
		Hmap.put(88888887,"MI");
		Hmap.put(88888888,"Blackberry");
		
		System.out.println("The mobile having Id " +mId+ " is " +Hmap.get(mId) );
		
	}

}