package com.cd.services;
import java.util.*;

import com.cd.dao.IMobileDAO;
import com.cd.dao.MobileDaoImpl;
import com.cd.model.Mobile;

public class MobileServiceImpl implements IMobileService {

	public void addMobile(Mobile m) {
		// TODO Auto-generated method stub
		
		ArrayList<String> list = new ArrayList<String>();
		list.add("Nokia");
		list.add("Samsung");
		list.add("Apple");
		list.add("Sony");
		list.add("Google");
		list.add("Honor");
		list.add("MI");
		list.add("Blackberry");

		/*
		 * Boolean m_n = false; Boolean i_d = false;
		 */
		int x = m.getId()/10000000;
		if (list.contains(m.getName()) && x <=9);{
			IMobileDAO dao = null;
			dao = new MobileDaoImpl();
			dao.addMobile(m);
		}
			
	}

	@Override
	public void deleteMobile(int mId) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(88888881);
		list.add(88888882);
		list.add(88888883);
		list.add(88888884);
		list.add(88888885);
		list.add(88888886);
		list.add(88888887);
		list.add(88888888);
		
		if (list.contains(mId))
		{	
			IMobileDAO dao = null;
			dao = new MobileDaoImpl();
			dao.deleteMobile(list.indexOf(mId));
		}
		else
			System.out.println("Enter valid ID");
	}

	@Override
	public void updateMobileDetails(int mId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void searchMobileById(int mId) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(88888881);
		list.add(88888882);
		list.add(88888883);
		list.add(88888884);
		list.add(88888885);
		list.add(88888886);
		list.add(88888887);
		list.add(88888888);	
		
		if(list.contains(mId)) {
			System.out.println("here");
			IMobileDAO dao1 = null;
			dao1 = new MobileDaoImpl();
			dao1.searchMobileById(mId);
			
		}
		
	}

}
