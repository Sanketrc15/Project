package com.cd.services;

import com.cd.model.Mobile;

public class MobileServiceImpl implements IMobileService {

	@Override
	public void addMobile(Mobile m) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteMobile(int mId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateMobileDetails(int mId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void searchMobileById(int mId) {
		// TODO Auto-generated method stub
		
	}

}
