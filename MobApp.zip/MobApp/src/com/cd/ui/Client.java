package com.cd.ui;
import java.util.Scanner;
import com.cd.model.Mobile;
import com.cd.services.*;
//import com.cd.services.MobileServiceImpl;
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Enter to Samsung Mobile Shop");
		Scanner s1 = new Scanner(System.in);
		System.out.println("1. Add Mobile");
		System.out.println("2. Search Mobile by ID");
		System.out.println("3. Display all Mobiles");
		System.out.println("4. Delete Mobile");
		System.out.println("5. Exit");
		int num = s1.nextInt();
		
		Mobile m = new Mobile();
		switch(num){
		
		case 1:
		{
			System.out.println("Enter the Mobile Name");
			String n = s1.next();
			System.out.println("Enter the Mobile Description ");
			String d = s1.next();
			System.out.println("Enter the Mobile ID");
			int i = s1.nextInt();
			System.out.println("Enter the Mobile Price");
			float p = s1.nextFloat();
			Mobile m1 = new Mobile(n,d,i,p); 
			
			IMobileService ims = null;
			ims = new MobileServiceImpl();
			ims.addMobile(m1);
			break;
		}
		
		case 2:
		{
			System.out.println("Enter the Mobile ID");
			int i = s1.nextInt();
			
			IMobileService ims = null;
			ims = new MobileServiceImpl();
			ims.searchMobileById(i);
			
			break;
		}
			
		case 3:
		{
			
		}
		
		case 4:
		{
			System.out.println("Enter the Mobile ID");
			int i = s1.nextInt();
			//m.getId();
			IMobileService ims = null;
			ims = new MobileServiceImpl();
			ims.deleteMobile(i);
			break;
		}
		
		default:
		{
			
		}
		
		
		}
	}

}
